# Altio — altioaem.com

Single-page marketing site for Altio, an autonomous exterior maintenance company in Santa Monica, CA.

## Stack

Pure static HTML / CSS / JSX. JSX is transpiled in the browser via Babel — no build step required.

## Deploy

Drop the whole folder into any static host:

- **Vercel** — `vercel deploy` from the folder root
- **Netlify** — drag the folder into the Netlify dashboard
- **GitHub Pages** — push to a repo, enable Pages on the `main` branch / root
- **Cloudflare Pages** — connect repo, no build command, output dir = `/`

The entry point is `index.html`. No `package.json`, no node_modules, no bundler.

## Files

```
index.html          # entry point — loads React + Babel from unpkg, then site scripts
styles.css          # brand tokens (color, type, base resets)
site-styles.css     # site-level layout primitives
marks.jsx           # logo + monogram + icon library (Wordmark, PeakMark, etc.)
site-1.jsx          # Nav, Hero, TrustBar, Services
site-2.jsx          # How it works, Why Altio (compare + testimonial), Properties (+ coverage map)
site-3.jsx          # SpecWall, FAQ, SurveyCTA, Footer, root mount
```

## Editing copy

All site copy lives directly in the `site-*.jsx` files as JSX strings — search for the text you want to change and edit in place. No CMS, no JSON config.

## Notes

- The in-browser Babel transformer logs a one-line "use precompiled scripts in production" warning. It's a recommendation, not a problem — the site works correctly. If you want to remove it, pre-build the JSX with a one-off `npx babel` step and swap the `<script type="text/babel">` tags for `<script>` tags.
- Fonts are loaded from Google Fonts (`Sora`, `Geist`, `Geist Mono`). They cache aggressively.
- No tracking, no analytics, no third-party requests beyond React, Babel, and Google Fonts.

## License

Proprietary — © Altio.
