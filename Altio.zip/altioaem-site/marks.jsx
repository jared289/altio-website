/* ============================================
   ALTIO — Marks Library
   Wordmark + monograms + icons, all drawn from
   geometric primitives so they stay crisp at any
   size and the brand is mathematically consistent.
   ============================================ */

// --- Core construction values ---
// All letters built on a 160-unit cap height, 20-unit stroke.
// Wordmark viewBox: 0 0 690 160 (letters across)
// Spacing reflects the source: generous, geometric, even.

const Wordmark = ({
  weight = 20,
  color = 'currentColor',
  className = '',
  style = {},
  showConstruction = false,
  tagline = false,
  taglineColor = 'var(--cyan)',
  ariaLabel = 'Altio',
}) => {
  const h = tagline ? 240 : 160;
  return (
    <svg
      viewBox={`0 0 690 ${h}`}
      className={className}
      style={{ width: '100%', height: 'auto', display: 'block', ...style }}
      aria-label={ariaLabel}
      role="img"
    >
      {showConstruction && (
        <g opacity="0.35" stroke="var(--cyan)" strokeWidth="0.5" fill="none">
          {/* Cap height + baseline */}
          <line x1="0" y1="10" x2="690" y2="10" strokeDasharray="2 3" />
          <line x1="0" y1="150" x2="690" y2="150" strokeDasharray="2 3" />
          <line x1="0" y1="80" x2="690" y2="80" strokeDasharray="2 3" />
          {/* O circle guide */}
          <circle cx="610" cy="80" r="70" />
          <circle cx="610" cy="80" r="2" fill="var(--cyan)" />
          {/* Letter origins */}
          {[20, 210, 405, 500, 610].map((x, i) => (
            <line key={i} x1={x} y1="-6" x2={x} y2="166" strokeDasharray="2 3" />
          ))}
        </g>
      )}
      <g
        stroke={color}
        strokeWidth={weight}
        fill="none"
        strokeLinecap="square"
        strokeLinejoin="miter"
      >
        {/* A — peak, no crossbar */}
        <polyline points="20,150 90,10 160,150" />
        {/* L */}
        <polyline points="210,10 210,150 310,150" />
        {/* T */}
        <line x1="350" y1="10" x2="460" y2="10" />
        <line x1="405" y1="10" x2="405" y2="150" />
        {/* I */}
        <line x1="500" y1="10" x2="500" y2="150" />
        {/* O — perfect circle (aperture) */}
        <circle cx="610" cy="80" r="70" />
      </g>
      {tagline && (
        <text
          x="22"
          y="210"
          fill={taglineColor}
          style={{
            fontFamily: 'Geist, system-ui, sans-serif',
            fontSize: 22,
            fontWeight: 400,
            letterSpacing: '0.02em',
          }}
        >
          Autonomous Exterior Maintenance
        </text>
      )}
    </svg>
  );
};

// --- Peak monogram — the A (altitude / summit) ---
const PeakMark = ({ weight = 24, color = 'currentColor', className = '', style = {} }) => (
  <svg
    viewBox="0 0 160 160"
    className={className}
    style={{ width: '100%', height: 'auto', display: 'block', ...style }}
    role="img"
    aria-label="Altio Peak"
  >
    <polyline
      points="10,150 80,10 150,150"
      stroke={color}
      strokeWidth={weight}
      fill="none"
      strokeLinecap="square"
      strokeLinejoin="miter"
    />
  </svg>
);

// --- Aperture monogram — the O (drone disc / clean lens) ---
const ApertureMark = ({ weight = 24, color = 'currentColor', className = '', style = {} }) => (
  <svg
    viewBox="0 0 160 160"
    className={className}
    style={{ width: '100%', height: 'auto', display: 'block', ...style }}
    role="img"
    aria-label="Altio Aperture"
  >
    <circle
      cx="80"
      cy="80"
      r="68"
      stroke={color}
      strokeWidth={weight}
      fill="none"
    />
  </svg>
);

// --- Stacked badge — Peak nested in Aperture, vertical mark ---
const BadgeMark = ({ color = 'currentColor', className = '', style = {} }) => (
  <svg
    viewBox="0 0 160 160"
    className={className}
    style={{ width: '100%', height: 'auto', display: 'block', ...style }}
    role="img"
    aria-label="Altio Badge"
  >
    <circle cx="80" cy="80" r="72" stroke={color} strokeWidth="6" fill="none" />
    <polyline
      points="42,110 80,46 118,110"
      stroke={color}
      strokeWidth="8"
      fill="none"
      strokeLinecap="square"
      strokeLinejoin="miter"
    />
  </svg>
);

// --- Drone (top-down quadcopter, geometric) ---
const DroneIcon = ({ color = 'currentColor', className = '', style = {} }) => (
  <svg
    viewBox="0 0 120 120"
    className={className}
    style={{ width: '100%', height: 'auto', display: 'block', ...style }}
    fill="none"
    stroke={color}
    strokeWidth="2.5"
    strokeLinecap="square"
  >
    {/* central body */}
    <rect x="50" y="50" width="20" height="20" />
    {/* arms */}
    <line x1="60" y1="50" x2="30" y2="22" />
    <line x1="60" y1="50" x2="90" y2="22" />
    <line x1="60" y1="70" x2="30" y2="98" />
    <line x1="60" y1="70" x2="90" y2="98" />
    {/* rotors */}
    <circle cx="22" cy="22" r="14" />
    <circle cx="98" cy="22" r="14" />
    <circle cx="22" cy="98" r="14" />
    <circle cx="98" cy="98" r="14" />
  </svg>
);

// --- Building (simple architectural form) ---
const BuildingIcon = ({ color = 'currentColor', className = '', style = {} }) => (
  <svg
    viewBox="0 0 120 120"
    className={className}
    style={{ width: '100%', height: 'auto', display: 'block', ...style }}
    fill="none"
    stroke={color}
    strokeWidth="2.5"
  >
    <rect x="20" y="14" width="80" height="92" />
    {[28, 44, 60, 76, 92].map(y => (
      <line key={y} x1="20" y1={y} x2="100" y2={y} />
    ))}
    {[40, 60, 80].map(x => (
      <line key={x} x1={x} y1="14" x2={x} y2="106" />
    ))}
  </svg>
);

// --- Sweep (spray fan from a point) ---
const SweepIcon = ({ color = 'currentColor', className = '', style = {} }) => (
  <svg
    viewBox="0 0 120 120"
    className={className}
    style={{ width: '100%', height: 'auto', display: 'block', ...style }}
    fill="none"
    stroke={color}
    strokeWidth="2.5"
    strokeLinecap="square"
  >
    <circle cx="60" cy="20" r="6" />
    {[-30, -15, 0, 15, 30].map((deg, i) => {
      const rad = (deg * Math.PI) / 180;
      const x = 60 + Math.sin(rad) * 90;
      const y = 20 + Math.cos(rad) * 90;
      return <line key={i} x1="60" y1="26" x2={x} y2={y} strokeDasharray="2 4" />;
    })}
  </svg>
);

// --- Path arrow (drone flight vector) ---
const PathIcon = ({ color = 'currentColor', className = '', style = {} }) => (
  <svg
    viewBox="0 0 120 120"
    className={className}
    style={{ width: '100%', height: 'auto', display: 'block', ...style }}
    fill="none"
    stroke={color}
    strokeWidth="2.5"
    strokeLinecap="square"
  >
    <path d="M 10 90 Q 40 90, 50 60 T 90 30" strokeDasharray="3 4" />
    <polyline points="78,22 96,28 90,42" />
  </svg>
);

// --- Drone path overlay pattern (used in pattern section + drone livery) ---
const DronePathPattern = ({ color = 'currentColor', dense = false, className = '', style = {} }) => {
  const lines = [];
  const step = dense ? 18 : 28;
  for (let y = 0; y < 240; y += step) {
    lines.push(
      <line key={`h-${y}`} x1="0" y1={y} x2="240" y2={y} stroke={color} strokeWidth="0.6" opacity="0.4" />
    );
  }
  return (
    <svg
      viewBox="0 0 240 240"
      preserveAspectRatio="xMidYMid slice"
      className={className}
      style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', ...style }}
    >
      {lines}
      <path
        d="M 10 220 Q 60 220, 80 160 T 120 90 Q 130 50, 180 30"
        stroke={color}
        strokeWidth="1.5"
        fill="none"
        opacity="0.9"
        strokeDasharray="4 4"
      />
      <circle cx="180" cy="30" r="3" fill={color} />
      <circle cx="10" cy="220" r="2" fill={color} opacity="0.6" />
    </svg>
  );
};

// --- Dot grid (clean surface metaphor / scan pattern) ---
const DotGrid = ({ color = 'currentColor', size = 240, gap = 16, className = '', style = {} }) => {
  const dots = [];
  for (let y = gap; y < size; y += gap) {
    for (let x = gap; x < size; x += gap) {
      dots.push(<circle key={`${x}-${y}`} cx={x} cy={y} r="1" fill={color} opacity="0.4" />);
    }
  }
  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      preserveAspectRatio="xMidYMid slice"
      className={className}
      style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', ...style }}
    >
      {dots}
    </svg>
  );
};

// --- Coastline scan (horizon line + repeating verticals) ---
const CoastScan = ({ color = 'currentColor', className = '', style = {} }) => (
  <svg
    viewBox="0 0 240 240"
    preserveAspectRatio="xMidYMid slice"
    className={className}
    style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', ...style }}
  >
    {[...Array(48)].map((_, i) => {
      const x = i * 5 + 2;
      const h = 30 + (Math.sin(i * 0.45) + 1) * 35;
      return (
        <line key={i} x1={x} y1={120} x2={x} y2={120 - h} stroke={color} strokeWidth="1" opacity="0.6" />
      );
    })}
    <line x1="0" y1="120" x2="240" y2="120" stroke={color} strokeWidth="1" />
    {[140, 160, 180, 200].map((y, i) => (
      <line key={y} x1="0" y1={y} x2="240" y2={y} stroke={color} strokeWidth="0.5" opacity={0.5 - i * 0.1} />
    ))}
  </svg>
);

Object.assign(window, {
  Wordmark,
  PeakMark,
  ApertureMark,
  BadgeMark,
  DroneIcon,
  BuildingIcon,
  SweepIcon,
  PathIcon,
  DronePathPattern,
  DotGrid,
  CoastScan,
});
