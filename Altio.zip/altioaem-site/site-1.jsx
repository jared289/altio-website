/* ============================================
   ALTIO SITE — Nav + Hero + Services
   ============================================ */

const { useState: useS1, useEffect: useE1, useRef: useR1 } = React;

// --------- Nav ---------
const Nav = () => {
  const [scrolled, setScrolled] = useS1(false);
  useE1(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={'nav' + (scrolled ? ' is-scrolled' : '')}>
      <div className="nav-inner">
        <a href="#top" className="nav-mark" aria-label="Altio — home">
          <Wordmark weight={20} style={{ width: 84 }} />
        </a>
        <nav className="nav-links">
          <a href="#services">Services</a>
          <a href="#how">How it works</a>
          <a href="#why">Why Altio</a>
          <a href="#properties">Properties</a>
        </nav>
        <div className="nav-right">
          <span className="muted" style={{ fontSize: 10 }}>+1 (310) 555-0144</span>
          <a href="#survey" className="btn btn-cyan">Request a Survey</a>
        </div>
      </div>
    </header>
  );
};

// --------- Hero ---------
const Hero = () => (
  <section className="hero" id="top">
    <div className="hero-grid-bg" />
    <div className="hero-content">
      <span className="eyebrow">Santa Monica · Westside LA</span>
      <h1>
        The exterior,<br />
        <span className="cyan">on autopilot.</span>
      </h1>
      <p className="hero-lede">
        Drone-led facade, window, and gutter cleaning for luxury hotels, HOAs, and commercial properties on LA's westside. No scaffolding. No lifts. No one on the wall.
      </p>
      <div className="hero-cta">
        <a href="#survey" className="btn btn-cyan">Request a Survey →</a>
        <a href="#how" className="btn-ghost btn">See how it works</a>
      </div>
      <div className="hero-stats">
        {[
          { v: '200', u: 'FT', lbl: 'Vertical reach' },
          { v: '4500', u: 'PSI', lbl: 'Calibrated pressure' },
          { v: '15K', u: 'SQ FT / HR', lbl: 'Coverage rate' },
          { v: '0', u: 'CREW AT HEIGHT', lbl: 'Height risk' },
          { v: '3×', u: 'FASTER', lbl: 'Versus manual' },
        ].slice(0, 3).map((s) => (
          <div key={s.lbl} className="hero-stat">
            <div className="v">{s.v}<span className="u">{s.u}</span></div>
            <div className="lbl">{s.lbl}</div>
          </div>
        ))}
      </div>
    </div>
    <HeroVisual />
  </section>
);

// Hero visual — Peak monogram with scan grid + flight path overlay
const HeroVisual = () => (
  <div className="hero-visual" aria-hidden="true">
    {/* layered pattern: scan grid + flight path */}
    <DotGrid color="var(--cyan)" size={400} gap={20} style={{ opacity: 0.18 }} />
    <DronePathPattern color="var(--cyan)" style={{ opacity: 0.35 }} />
    {/* central monogram */}
    <div style={{
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexDirection: 'column',
      gap: 32,
      zIndex: 2,
    }}>
      <div style={{ width: '46%', maxWidth: 240 }}>
        <PeakMark color="var(--salt)" />
      </div>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.18em', color: 'var(--cyan)', textTransform: 'uppercase', marginBottom: 6 }}>
          ● Sherpa-04 · live
        </div>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.12em', color: 'var(--salt-3)' }}>
          34.0195°N · 118.4912°W
        </div>
      </div>
    </div>
    {/* corner stats */}
    <div style={{ position: 'absolute', top: 20, left: 20, fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.18em', color: 'var(--cyan)', textTransform: 'uppercase' }}>
      ALT.0001 · LIVE
    </div>
    <div style={{ position: 'absolute', top: 20, right: 20, fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.18em', color: 'var(--salt-3)', textTransform: 'uppercase' }}>
      06:34 PDT
    </div>
    <div style={{ position: 'absolute', bottom: 20, left: 20, fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.18em', color: 'var(--salt-3)', textTransform: 'uppercase' }}>
      WIND 8MPH · CEILING 18
    </div>
    <div style={{ position: 'absolute', bottom: 20, right: 20, fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '0.18em', color: 'var(--salt-3)', textTransform: 'uppercase' }}>
      STATUS · GREEN
    </div>
  </div>
);

// --------- Trust bar ---------
const TrustBar = () => (
  <section className="trustbar" aria-label="Property types served">
    <div className="trustbar-inner">
      <span className="label">Serving</span>
      <div className="clients">
        <span className="client">Luxury Beachfront Hotels</span>
        <span className="client">Luxury HOAs</span>
        <span className="client">Commercial Office</span>
        <span className="client">High-Rise Condos</span>
      </div>
    </div>
  </section>
);

// --------- Services ---------
const Services = () => {
  const services = [
    {
      tag: 'Core service · Sherpa drone',
      title: 'Facade Cleaning',
      desc: 'Full-building exterior wash on stucco, glass curtain wall, brick, and metal panel. Calibrated soft-wash to high-pressure on the same drone.',
      specs: ['UP TO 200 FT', '4500 PSI', '15K SQ FT / HR'],
      icon: BuildingIcon,
      core: true,
    },
    {
      tag: 'Sherpa drone',
      title: 'Window Cleaning',
      desc: 'Streak-free windows at any height via on-board chemical injection — dosed and switched directly from the flight controller.',
      specs: ['CHEM INJECTION', 'FLIGHT-CONTROLLER DOSING', 'NO LADDERS'],
      icon: SweepIcon,
      core: false,
    },
    {
      tag: 'Sherpa drone',
      title: 'Gutter Cleaning',
      desc: 'Inspect and clear gutters from above with no rooftop access. Drone vision identifies blockages; high-pressure clears them.',
      specs: ['NO ROOF ACCESS', 'INSPECT + CLEAR', 'PHOTO REPORT'],
      icon: PathIcon,
      core: false,
    },
    {
      tag: 'Ground service · Lavo AI Lucid Bot',
      title: 'Parking Garages',
      desc: 'Fully autonomous ground robot. AI-powered navigation maps the deck; Click-and-Clean technology runs the route. No flagger, no closures.',
      specs: ['AUTONOMOUS', 'AI NAVIGATION', '6K SQ FT / HR'],
      icon: DroneIcon,
      core: true,
    },
  ];
  return (
    <section className="section" id="services">
      <div className="section-wrap">
        <header className="section-head">
          <span className="section-num">01 / Services</span>
          <div>
            <span className="eyebrow">Four services. Two platforms.</span>
            <h2 className="section-title">
              Everything outside,<br />
              <em>handled by robots.</em>
            </h2>
            <p className="section-lede">
              The Sherpa drone takes elevated work — facade, windows, gutters. The Lavo AI Lucid Bot covers ground level. One vendor, two platforms, every exterior surface.
            </p>
          </div>
        </header>

        <div className="svc-list" style={{ gridTemplateColumns: 'repeat(2, 1fr)' }}>
          {services.map((s) => (
            <article key={s.title} className={'svc ' + (s.core ? 'core' : 'standard')}>
              <span className="svc-tag">{s.tag}</span>
              <s.icon color="var(--salt)" style={{ width: 36, height: 36, marginTop: 4 }} />
              <h4>{s.title}</h4>
              <p>{s.desc}</p>
              <div className="specs">{s.specs.join(' · ')}</div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

Object.assign(window, { Nav, Hero, TrustBar, Services });
