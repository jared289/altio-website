/* ============================================
   ALTIO SITE — How / Compare / Properties
   ============================================ */

// --------- How it works ---------
const HowItWorks = () => {
  const steps = [
    {
      n: 'Step 01',
      title: 'Altio arrives.',
      desc: 'One vehicle. Full system. The Cybertruck platform carries both robots, water, power, and chem — your loading dock sees one truck, not a convoy.',
      detail: 'CT-02 mobile platform · 1 driver · 1 operator',
      Icon: SweepIcon,
    },
    {
      n: 'Step 02',
      title: 'Sherpa flies the walls.',
      desc: 'The drone runs facade, windows, and gutters in a single pass. Pre-programmed route, real-time pressure modulation, and a flight controller that doses chemistry per surface.',
      detail: '200 ft reach · 4500 PSI · 15K sq ft / hr',
      Icon: PathIcon,
    },
    {
      n: 'Step 03',
      title: 'Lavo takes the deck.',
      desc: 'While Sherpa is on the wall, the Lavo AI Lucid Bot maps the parking garage and runs Click-and-Clean — autonomous floor cleaning with no flaggers, no closures.',
      detail: 'AI navigation · 6K sq ft / hr · zero supervisor',
      Icon: DroneIcon,
    },
    {
      n: 'Step 04',
      title: 'Done. No callbacks.',
      desc: 'A photo report lands in your inbox before the truck leaves. The next visit is already on the schedule. No scaffolding came down because none went up.',
      detail: 'Photo report · standing schedule · zero scaffolding',
      Icon: BuildingIcon,
    },
  ];
  return (
    <section className="section alt" id="how">
      <div className="section-wrap">
        <header className="section-head">
          <span className="section-num">02 / How it works</span>
          <div>
            <span className="eyebrow">One arrival · two robots · full exterior</span>
            <h2 className="section-title">
              In and out before <em>brunch service.</em>
            </h2>
            <p className="section-lede">
              A 50,000 sq ft facade that takes a 12-person crew four to eight weeks takes Altio under a week, with no one above ground level.
            </p>
          </div>
        </header>

        <div className="steps" style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>
          {steps.map((s) => (
            <article key={s.n} className="step">
              <span className="step-n">{s.n}</span>
              <s.Icon color="var(--cyan)" className="step-icon" />
              <h3>{s.title}</h3>
              <p>{s.desc}</p>
              <div className="step-detail">{s.detail}</div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

// --------- Compare ---------
const WhyAltio = () => {
  const rows = [
    {
      trad: '8–12 jobs per year — bottlenecked by lift scheduling.',
      altio: '100+ jobs per year — no lift dependency.',
    },
    {
      trad: '$47K bid for a 50K sq ft facade.',
      altio: '$32K bid on the same job. 3× the margin.',
    },
    {
      trad: '4–8 week timeline. 12 technicians on site.',
      altio: 'Under one week. 4 employees end-to-end.',
    },
    {
      trad: 'Work at height risk — $42K average insurance claim.',
      altio: 'Crew stays on the ground. Zero height risk.',
    },
    {
      trad: 'Can\'t reach above 100 ft without specialized scaffold.',
      altio: 'Handles up to 200 ft easily, every time.',
    },
    {
      trad: 'Multiple vendors. Multiple invoices. Multiple no-shows.',
      altio: 'One vendor. One invoice. One contact.',
    },
  ];
  return (
    <section className="section" id="why">
      <div className="section-wrap">
        <header className="section-head">
          <span className="section-num">03 / Why Altio</span>
          <div>
            <span className="eyebrow">Versus traditional pressure-wash crews</span>
            <h2 className="section-title">
              The numbers <span className="cyan">don't compare.</span>
            </h2>
            <p className="section-lede">
              Traditional facade cleaning is constrained by scaffolds, lifts, and headcount. Altio replaces all three with two robots on one truck — and the economics change at every line.
            </p>
          </div>
        </header>

        <div className="compare">
          <div className="compare-col">
            <h3>
              Traditional crews
              <span className="tag">Scaffold-bound</span>
            </h3>
            <ul>
              {rows.map((r, i) => <li key={i}>{r.trad}</li>)}
            </ul>
          </div>
          <div className="compare-col altio">
            <h3>
              Altio
              <span className="tag">Drone-led</span>
            </h3>
            <ul>
              {rows.map((r, i) => <li key={i}>{r.altio}</li>)}
            </ul>
          </div>
        </div>

        {/* Testimonial pull-quote */}
        <div style={{ marginTop: 96 }}>
          <div className="testimonial">
            <div>
              <div className="testimonial-q">
                The north facade used to be a six-week production with scaffolding on Ocean Avenue. Altio finished it before the weekend.
              </div>
              <div className="testimonial-attr">
                <div className="avatar">EV</div>
                <div>
                  <div className="who">Elena Vasquez</div>
                  <div className="title">General Manager · Maison 27, Venice</div>
                </div>
              </div>
            </div>
            <div className="metrics">
              <div className="metric">
                <div className="k">Facade · Maison 27</div>
                <div className="v">24,800<span className="u">SQ FT</span></div>
              </div>
              <div className="metric">
                <div className="k">Time on site</div>
                <div className="v">1.7<span className="u">HRS</span></div>
              </div>
              <div className="metric">
                <div className="k">Scaffolding</div>
                <div className="v">0<span className="u">FT</span></div>
              </div>
              <div className="metric">
                <div className="k">Crew at height</div>
                <div className="v">0<span className="u">PEOPLE</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// --------- Properties / Clients ---------
const PropertiesSection = () => {
  const properties = [
    { name: 'Beachfront hotels', city: 'Santa Monica · Venice', badge: 'Salt-air priority', PatternComp: CoastScan },
    { name: 'Luxury HOAs', city: 'Brentwood · Beverly Hills', badge: 'Standing service', PatternComp: DotGrid },
    { name: 'Commercial office', city: 'West Hollywood', badge: 'Quarterly cycle', PatternComp: DronePathPattern },
    { name: 'High-rise condos', city: 'Wilshire corridor', badge: 'Up to 200 ft', PatternComp: CoastScan },
  ];
  return (
    <section className="section alt" id="properties">
      <div className="section-wrap">
        <header className="section-head">
          <span className="section-num">04 / Properties</span>
          <div>
            <span className="eyebrow">Built for the Westside</span>
            <h2 className="section-title">
              Coastal property is <em>relentless</em>.<br />
              So is our schedule.
            </h2>
            <p className="section-lede">
              Salt air accelerates buildup. Beachfront facades need 2–3× the service frequency of inland buildings — and standing-service clients receive monthly inspections, quarterly washes, and a property report on every visit.
            </p>
          </div>
        </header>

        <div className="properties" style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>
          {properties.map((p) => (
            <article key={p.name} className="property">
              <div className="ph ph-arch">
                <p.PatternComp color="var(--cyan)" style={{ opacity: 0.55 }} />
              </div>
              <span className="badge">{p.badge}</span>
              <div className="meta">
                <div className="name">{p.name}</div>
                <div className="city">{p.city}</div>
              </div>
            </article>
          ))}
        </div>

        {/* Coverage list + map */}
        <div className="coverage" style={{ marginTop: 4 }}>
          <div className="coverage-list">
            <h3>Service coverage</h3>
            {[
              ['Santa Monica', '< 20 min'],
              ['Venice', '< 25 min'],
              ['Brentwood', '< 30 min'],
              ['West Hollywood', '< 35 min'],
              ['Beverly Hills', '< 30 min'],
            ].map(([city, eta]) => (
              <div key={city} className="coverage-row">
                <span className="city">{city}</span>
                <span className="eta">{eta}</span>
              </div>
            ))}
            <div style={{ marginTop: 24, fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.04em', color: 'var(--salt-3)', lineHeight: 1.7 }}>
              Dispatched from Santa Monica HQ.<br />
              On-site response within 35 minutes across the Westside.
            </div>
          </div>
          <CoverageMap />
        </div>
      </div>
    </section>
  );
};

const CoverageMap = () => (
  <div className="coverage-map" aria-hidden="true">
    <svg viewBox="0 0 640 540" preserveAspectRatio="xMidYMid slice" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
      {/* grid */}
      <g opacity="0.4">
        {[...Array(20)].map((_, i) => (
          <line key={'h' + i} x1="0" y1={i * 30} x2="640" y2={i * 30} stroke="var(--hairline)" strokeWidth="0.6" />
        ))}
        {[...Array(22)].map((_, i) => (
          <line key={'v' + i} x1={i * 30} y1="0" x2={i * 30} y2="540" stroke="var(--hairline)" strokeWidth="0.6" />
        ))}
      </g>

      {/* coastline — abstract pacific coast curve */}
      <path
        d="M 0 360 Q 80 340, 140 320 T 280 280 Q 340 260, 380 220 T 460 150 Q 500 110, 560 80 L 640 60 L 640 540 L 0 540 Z"
        fill="rgba(61,140,255,0.04)"
        stroke="var(--cyan)"
        strokeWidth="1"
        opacity="0.6"
      />

      {/* HQ dot — Santa Monica */}
      <g transform="translate(180 290)">
        <circle r="80" fill="var(--cyan)" opacity="0.08" />
        <circle r="50" fill="var(--cyan)" opacity="0.14" />
        <circle r="20" fill="var(--cyan)" opacity="0.25" />
        <circle r="6" fill="var(--cyan)" />
        <text x="14" y="-12" fill="var(--cyan)" fontFamily="Geist Mono, monospace" fontSize="10" letterSpacing="0.16em">
          ALTIO HQ
        </text>
        <text x="14" y="2" fill="var(--salt-2)" fontFamily="Geist Mono, monospace" fontSize="9" letterSpacing="0.1em">
          Santa Monica, CA
        </text>
      </g>

      {/* cities */}
      {[
        { x: 220, y: 350, label: 'Venice' },
        { x: 240, y: 240, label: 'Brentwood' },
        { x: 350, y: 230, label: 'Beverly Hills' },
        { x: 400, y: 180, label: 'West Hollywood' },
      ].map((c) => (
        <g key={c.label} transform={`translate(${c.x} ${c.y})`}>
          <circle r="4" fill="var(--salt)" />
          <circle r="14" fill="none" stroke="var(--salt)" strokeWidth="0.5" opacity="0.3" />
          <text x="10" y="4" fill="var(--salt-2)" fontFamily="Geist Mono, monospace" fontSize="9" letterSpacing="0.12em">
            {c.label}
          </text>
        </g>
      ))}

      {/* compass */}
      <g transform="translate(580 60)" opacity="0.5">
        <circle r="20" fill="none" stroke="var(--salt-3)" strokeWidth="0.5" />
        <line x1="0" y1="-20" x2="0" y2="-12" stroke="var(--cyan)" strokeWidth="1" />
        <line x1="0" y1="12" x2="0" y2="20" stroke="var(--salt-3)" strokeWidth="0.5" />
        <line x1="-20" y1="0" x2="-12" y2="0" stroke="var(--salt-3)" strokeWidth="0.5" />
        <line x1="12" y1="0" x2="20" y2="0" stroke="var(--salt-3)" strokeWidth="0.5" />
        <text x="0" y="-26" fill="var(--cyan)" fontFamily="Geist Mono, monospace" fontSize="8" letterSpacing="0.16em" textAnchor="middle">N</text>
      </g>

      {/* coordinates label */}
      <text x="24" y="520" fill="var(--salt-3)" fontFamily="Geist Mono, monospace" fontSize="9" letterSpacing="0.16em">
        34.0195°N · 118.4912°W
      </text>
      <text x="616" y="520" textAnchor="end" fill="var(--salt-3)" fontFamily="Geist Mono, monospace" fontSize="9" letterSpacing="0.16em">
        WESTSIDE · LOS ANGELES
      </text>
    </svg>
  </div>
);

Object.assign(window, { HowItWorks, WhyAltio, PropertiesSection });
