/* ============================================
   ALTIO SITE — Specs / FAQ / CTA / Footer + Mount
   ============================================ */

// --------- Spec wall (mid-page reinforcement) ---------
const SpecWall = () => (
  <section className="section salt" aria-label="Tech specs">
    <div className="section-wrap">
      <header className="section-head" style={{ marginBottom: 56 }}>
        <span className="section-num">—</span>
        <div>
          <span className="eyebrow">The numbers</span>
          <h2 className="section-title" style={{ color: 'var(--ink)' }}>
            The story is the<br />
            <em>spec sheet.</em>
          </h2>
        </div>
      </header>
      <div className="spec-wall" style={{ background: 'rgba(5,8,12,0.10)' }}>
        {[
          { k: 'Vertical reach', v: '200', u: 'FT', lbl: 'Twenty stories without ground contact.' },
          { k: 'Calibrated pressure', v: '4500', u: 'PSI', lbl: 'Soft-wash to high-pressure on one nozzle.' },
          { k: 'Sherpa throughput', v: '15K', u: 'SQ FT / HR', lbl: 'Coverage rate per drone, facade depth.' },
          { k: 'Lavo throughput', v: '6K', u: 'SQ FT / HR', lbl: 'Autonomous parking-deck floor coverage.' },
          { k: 'Crew at height', v: '0', u: 'PEOPLE', lbl: 'No scaffold. No rope access. No risk.' },
        ].map((s) => (
          <div key={s.k} className="cell" style={{ background: 'var(--salt)', color: 'var(--ink)' }}>
            <span className="k">{s.k}</span>
            <span className="v" style={{ color: 'var(--ink)' }}>{s.v}<span className="u" style={{ color: 'var(--pacific)' }}>{s.u}</span></span>
            <span className="lbl" style={{ color: '#3a4049' }}>{s.lbl}</span>
          </div>
        ))}
      </div>
    </div>
  </section>
);

// --------- FAQ ---------
const FAQ = () => {
  const [open, setOpen] = React.useState(0);
  const items = [
    {
      q: 'Do you actually use drones to clean buildings?',
      a: 'Yes. We operate a fleet of Lucid Bots Sherpa cleaning drones — purpose-built industrial UAVs that carry a 4500 PSI line and dose chemistry from on-board reservoirs. They reach surfaces up to 200 ft above ground without any scaffold, lift, or rope access.',
    },
    {
      q: 'What surfaces can the Sherpa drone clean?',
      a: 'Stucco, glass curtain wall, brick, metal panel, painted concrete, and most coated facade systems. Pressure and chemistry are calibrated per surface — the drone soft-washes a Venetian plaster wall and high-pressures a parking structure wall on the same job.',
    },
    {
      q: 'Is it safe? Insured?',
      a: 'The whole point is safety: no one is on the wall. We are licensed, fully insured, and FAA Part 107 certified. Traditional pressure-wash crews carry an average $42,000 work-at-height claim per incident — Altio carries zero, because there is no one at height to fall.',
    },
    {
      q: 'How long does a typical facade job take?',
      a: 'A 50,000 sq ft facade that traditionally requires 4–8 weeks and 12 technicians completes in under one week with Altio — usually with 4 employees on site. Most beachfront hotels are scoped in a single visit.',
    },
    {
      q: 'What happens in the parking garage while you\'re on the wall?',
      a: 'The Lavo AI Lucid Bot — our autonomous ground robot — runs simultaneously. It maps the deck using AI navigation, then executes the cleaning route via Click-and-Clean. No flagger, no closures, no second visit.',
    },
    {
      q: 'Do you offer standing service?',
      a: 'Yes. Most beachfront and Westside properties operate on a recurring cycle — monthly inspections, quarterly washes, on-condition response after weather events. We deliver a photo report on every visit.',
    },
  ];
  return (
    <section className="section" id="faq">
      <div className="section-wrap">
        <header className="section-head">
          <span className="section-num">05 / FAQ</span>
          <div>
            <span className="eyebrow">For property managers + GMs</span>
            <h2 className="section-title">
              The questions <em>every property manager asks.</em>
            </h2>
          </div>
        </header>

        <div className="faq">
          {items.map((it, i) => (
            <div
              key={i}
              className={'faq-row' + (open === i ? ' is-open' : '')}
              onClick={() => setOpen(open === i ? -1 : i)}
              role="button"
              aria-expanded={open === i}
            >
              <span className="faq-n">{String(i + 1).padStart(2, '0')}</span>
              <div>
                <div className="faq-q">{it.q}</div>
                <div className="faq-a">{it.a}</div>
              </div>
              <span className="faq-toggle">+</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// --------- CTA / survey form ---------
const SurveyCTA = () => {
  const [submitted, setSubmitted] = React.useState(false);
  const onSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };
  return (
    <section className="cta-section" id="survey">
      <div className="cta-inner">
        <div>
          <span className="eyebrow">Request a survey</span>
          <h2>
            See what your facade<br />
            <em>actually looks like.</em>
          </h2>
          <p>
            Tell us about the property. We send a Sherpa for a no-cost survey flight, return a photo report, and quote a standing-service cycle. Two minutes to fill out. Zero obligation.
          </p>
          <div style={{ marginTop: 40, display: 'flex', gap: 32, flexWrap: 'wrap', fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(5,8,12,0.7)' }}>
            <span>● Licensed</span>
            <span>● Insured</span>
            <span>● FAA Part 107 Certified</span>
          </div>
        </div>

        <form className="cta-form" onSubmit={onSubmit}>
          {!submitted ? (
            <>
              <div className="hd">Survey request · PRPR-{new Date().getFullYear()}</div>
              <div className="field">
                <label>Your name</label>
                <input type="text" placeholder="Elena Vasquez" required />
              </div>
              <div className="field">
                <label>Email</label>
                <input type="email" placeholder="e.vasquez@maison27.com" required />
              </div>
              <div className="field">
                <label>Property name</label>
                <input type="text" placeholder="Maison 27" required />
              </div>
              <div className="row">
                <div className="field">
                  <label>Property type</label>
                  <select required defaultValue="">
                    <option value="" disabled>Select…</option>
                    <option>Beachfront hotel</option>
                    <option>Luxury HOA</option>
                    <option>Commercial office</option>
                    <option>High-rise condo</option>
                    <option>Other</option>
                  </select>
                </div>
                <div className="field">
                  <label>City</label>
                  <select required defaultValue="">
                    <option value="" disabled>Select…</option>
                    <option>Santa Monica</option>
                    <option>Venice</option>
                    <option>Brentwood</option>
                    <option>West Hollywood</option>
                    <option>Beverly Hills</option>
                    <option>Other Westside</option>
                  </select>
                </div>
              </div>
              <div className="field">
                <label>Anything else?</label>
                <input type="text" placeholder="Approx. sq ft, services of interest…" />
              </div>
              <button type="submit" className="submit">Send request →</button>
              <div className="fine">Response within one business day · Santa Monica HQ</div>
            </>
          ) : (
            <div style={{ textAlign: 'center', padding: '48px 0' }}>
              <div className="hd" style={{ marginBottom: 24 }}>Survey received</div>
              <div style={{ fontFamily: 'var(--display)', fontWeight: 300, fontSize: 24, letterSpacing: '-0.02em', color: 'var(--salt)', lineHeight: 1.2, marginBottom: 16 }}>
                Thanks. We'll be in touch within one business day.
              </div>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.14em', color: 'var(--salt-3)', textTransform: 'uppercase' }}>
                Reference · PRPR-{new Date().getFullYear()}-{Math.floor(Math.random() * 9000 + 1000)}
              </div>
            </div>
          )}
        </form>
      </div>
    </section>
  );
};

// --------- Footer ---------
const Footer = () => (
  <footer className="footer">
    <div className="footer-inner">
      <div className="footer-top">
        <div className="footer-brand">
          <Wordmark weight={20} style={{ width: 140 }} />
          <p>Autonomous exterior maintenance for luxury hotels, HOAs, and commercial properties on LA's westside.</p>
          <div style={{ marginTop: 24, fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.12em', color: 'var(--salt-3)', lineHeight: 1.8 }}>
            Santa Monica, CA<br />
            +1 (310) 555-0144<br />
            hello@altioaem.com
          </div>
        </div>
        <div className="footer-col">
          <h5>Services</h5>
          <ul>
            <li><a href="#services">Facade cleaning</a></li>
            <li><a href="#services">Window cleaning</a></li>
            <li><a href="#services">Gutter cleaning</a></li>
            <li><a href="#services">Parking garages</a></li>
          </ul>
        </div>
        <div className="footer-col">
          <h5>Company</h5>
          <ul>
            <li><a href="#how">How it works</a></li>
            <li><a href="#why">Why Altio</a></li>
            <li><a href="#properties">Properties</a></li>
            <li><a href="#faq">FAQ</a></li>
          </ul>
        </div>
        <div className="footer-col">
          <h5>Coverage</h5>
          <ul>
            <li>Santa Monica</li>
            <li>Venice</li>
            <li>Brentwood</li>
            <li>West Hollywood</li>
            <li>Beverly Hills</li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} Altio · Autonomous Exterior Maintenance</span>
        <span>Licensed · Insured · FAA Part 107 Certified</span>
        <div className="legal">
          <a href="#" style={{ color: 'var(--salt-3)' }}>Privacy</a>
          <a href="#" style={{ color: 'var(--salt-3)' }}>Terms</a>
        </div>
      </div>
    </div>
  </footer>
);

// --------- App ---------
const SiteApp = () => (
  <>
    <Nav />
    <main>
      <Hero />
      <TrustBar />
      <Services />
      <HowItWorks />
      <WhyAltio />
      <SpecWall />
      <PropertiesSection />
      <FAQ />
      <SurveyCTA />
    </main>
    <Footer />
  </>
);

const siteRoot = ReactDOM.createRoot(document.getElementById('root'));
siteRoot.render(<SiteApp />);
